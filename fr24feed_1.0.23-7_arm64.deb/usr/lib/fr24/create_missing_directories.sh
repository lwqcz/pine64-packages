#!/bin/bash

# Sometimes Raspberry Pi /var/log and /run partitions are mounted as tmpfs
# Hence directories are lost after reboot and not all 3rdparty apps can
# handle this properly. Hence we have to provide a hack to create these dirs.
# Setting rwx permissions for now, TODO: set proper permissions

function create_dir_if_not_exists {
    DIR=$1
    PERMISSIONS=$2

    if [ ! -e ${DIR} ]; then
        mkdir -p ${DIR} || true
        chmod -R ${PERMISSIONS} ${DIR} || true
    fi
}

create_dir_if_not_exists "/run/dump1090-mutability" "a+rwx"
create_dir_if_not_exists "/var/log/fr24feed" "a+rx"
create_dir_if_not_exists "/run/fr24feed" "a+rx"
create_dir_if_not_exists "/var/log/lighttpd" "a+rwx"
create_dir_if_not_exists "/var/log/dirmngr" "a+rwx"

touch /dev/shm/decoder.txt
chown -R fr24:fr24 /dev/shm/decoder.txt /run/fr24feed /var/log/fr24feed

