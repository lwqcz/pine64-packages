#!/bin/bash

# Stop on first error
set -e

LOGFILE=/var/log/fr24feed_install_dump1090.log
exec > >(tee -a $LOGFILE)
exec 2>&1

if grep -q "^receiver.*dvbt" /etc/fr24feed.ini && [ ! -e /usr/lib/fr24/dump1090 ] ; then
    echo "dump1090 is not found, downloading dump1090-mutability..."

    # to skip any questions from APT
    export DEBIAN_FRONTEND=noninteractive

    echo 'dump1090-mutability dump1090-mutability/auto-start boolean false' | debconf-set-selections -v

    apt-get update -y
    apt-get -o Dpkg::Options::="--force-confdef" -o Dpkg::Options::="--force-confold" install librtlsdr0 libusb-1.0-0 dirmngr lighttpd wget -y

    # Download and install dump1090-mutability
    wget -O /tmp/dump1090-mutability_1.14_armhf.deb https://github.com/mutability/dump1090/releases/download/v1.14/dump1090-mutability_1.14_armhf.deb
    dpkg -i /tmp/dump1090-mutability_1.14_armhf.deb
    rm -f /tmp/dump1090-mutability_1.14_armhf.deb

    ln -s /usr/bin/dump1090-mutability /usr/lib/fr24/dump1090

    lighty-enable-mod dump1090 || true
    service lighttpd force-reload || true
    systemctl enable lighttpd || true
    systemctl start lighttpd || true

    echo "dump1090-mutability is installed. You can always override it in /etc/fr24feed.ini with any other supported driver."
    echo "Web server (aircraft map) at http://YOUR_DEVICE_IP/dump1090 is enabled by default."
fi

