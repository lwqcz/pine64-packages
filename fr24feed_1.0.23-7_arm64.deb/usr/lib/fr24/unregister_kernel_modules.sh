#!/bin/bash

# if that's the first time install, kernel might have this modules loaded which will prevent dump1090 to start
rmmod dvb_usb_rtl28xxu || true
rmmod rtl2832 || true
rmmod e4000 || true

