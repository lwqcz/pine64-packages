#!/bin/bash

PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"

INSTALLED_PREFIX="Installed: "
CANDIDATE_PREFIX="Candidate: "

$(mount | grep " on / " | grep rw) || {
    NEEDS_REMOUNT=true
    mount -o remount,rw /
}

apt-get update -y
INSTALLED_VERSION=`apt-cache policy fr24feed | grep "$INSTALLED_PREFIX" | sed "s/[[:blank:]]*$INSTALLED_PREFIX[[:blank:]]*//"`
CANDIDATE_VERSION=`apt-cache policy fr24feed | grep "$CANDIDATE_PREFIX" | sed "s/[[:blank:]]*$CANDIDATE_PREFIX[[:blank:]]*//"`

echo "Installed version: $INSTALLED_VERSION"
echo "Latest available: $CANDIDATE_VERSION"

# will show fr24feed in the list if previous installation failed
PROBLEMS=`dpkg --audit fr24feed | grep fr24feed`

if [[ "$INSTALLED_VERSION" != "$CANDIDATE_VERSION" || "$PROBLEMS" != "" ]]
then
    echo "Upgrading fr24feed from $INSTALLED_VERSION to $CANDIDATE_VERSION..."
    echo "Waiting for fr24feed to stop completely..."
    systemctl stop fr24feed

    PID=`pidof fr24feed`
    if [ ! -z "$PID" ]; then
        sleep 30
        pkill -9 -P $PID
        kill -9 $PID
    fi

    dpkg --force-confdef --force-confold --configure fr24feed || true

    apt-get -o Dpkg::Options::="--force-confdef" -o Dpkg::Options::="--force-confold" install -y fr24feed || echo "Failed to update, restarting current version..."
    systemctl restart fr24feed
else
    echo "Latest version is already installed"
fi

if [ "${NEEDS_REMOUNT}" = true ]; then
    mount -o remount,ro /
fi

